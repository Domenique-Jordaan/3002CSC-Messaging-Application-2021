//Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
//April 2021
//ChatHub class for Chat Application

import java.net.InetAddress;
import java.net.UnknownHostException;

/** ChatHub class for Chat Application
 * @author Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
 * @version 1.0
 * @since 2021-04-03
 */
public class ChatHub{

	/** Main method
	 *
	 * @param args the command-line arguments
	 */
	public static void main(String[] args){
		if (args.length != 1) {
			System.out.println("Correct syntax: ChatHub <hostname>");
			System.exit(0);
		}

		String hostname = args[0];

		try{
			InetAddress a = InetAddress.getByName(hostname);
			Server0 server = new Server0(a, 4446);
			server.run();
		}

		catch (UnknownHostException e) {
			System.out.println("Unknown host error.");
			System.exit(0);
		}
	}
}