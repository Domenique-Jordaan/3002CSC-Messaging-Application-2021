//Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
//April 2021
//ChatServer class for Chat Application

import java.net.*;
import java.util.ArrayList;
import java.util.Collections;
import java.io.IOException;

/** ChatServer class for Chat Application
 * @author Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
 * @version 1.0
 * @since 2021-04-03
 */
public class ChatServer extends Server implements Runnable{
	/**
	 * Socket for broadcasting and receiving messages
	 */
	private DatagramSocket socket;

	/**
	 * The InetAddress
	 */
	private InetAddress thisAddr;

	/**
	 * The port number
	 */
	private int thisPort;

	/**
	 * The group address that is being broadcasted to
	 */
	private InetAddress group;

	/**
	 * The group port number
	 */
	private int grpPort;

	/**
	 * The list of users in the chat
	 */
	private ArrayList<User> userList;

	/**
	 * The chat name
	 */
	private String chatName;

	/**
	 * Used to keep the chat going
	 */
	private boolean notEnded=true;

	/** Constructor
	 *
	 * @param cname the chat name
	 * @param ul the list of users in the chat
	 * @param time the time the chat was created
	 * @param gp the group port
	 * @param ga the group address
	 * @param sp the socket used
	 */
	public ChatServer(String cname, User[] ul, String time, int gp, String ga, int sp){
      
      super(true);//isChatServer set to true in Server
      
      try{
         socket= new DatagramSocket(sp);
      }
      catch(SocketException e){
         System.out.println("Error setting up chat server's socket for "+chatName);
      }
      
      try{
        group= InetAddress.getByName(ga);
        super.gAddress=group;
      }
      catch(UnknownHostException e){
        System.out.println("No address for "+ga);
      }
      
      grpPort=gp;
      super.gPort=gp;
          
      chatName=cname;
      userList= new ArrayList<User>();
      for(User u: ul){
           userList.add(u);
      }
      	
		String openMSG= "Post: ConfirmChatOpen\n";
		
		super.send( openMSG, group, grpPort, socket, userList.size(), "" , null);
	}

	/**
	 * Run method
	 */
	public void run(){
		while(notEnded){
			try{
				socket.setSoTimeout(0);
				receive();
				if(userList.size()<=1){
               System.out.println("CHAT SERVER FOR "+ chatName+ " HAS ENDED");
					notEnded=false;
               socket.close();
				}
			}

			catch(SocketException e){
				System.out.println("Error resetting timeout in " + chatName + ".");
				System.exit(0);
			}

		}
	}

	/**
	 * Receives packets
	 */
	public void receive(){
      byte[] buf= new byte[512];
		DatagramPacket msg= new DatagramPacket(buf, buf.length);

	   try{
         socket.setSoTimeout(0);
		   socket.receive(msg);
      }
      catch (IOException e){
         System.out.println("Error receiving in chatServer "+ chatName);
      }
      
		String msgText= new String(msg.getData(), 0, msg.getLength());
      
      System.out.println("----------------------------\nCHATSERVER RECEIVED:\n"+msgText+"\n---------------------------");

		if(!(super.goodCheckSum(msgText))){
			return;
		}

		msgText= super.stripChecksum(msgText);
		String[] msgparts= msgText.split("\n");
      
      if(msgparts.length==1){
         return;
      }

		if(isDuplicate(msgparts[0],msgText)){
         super.sendAck(group, grpPort, msgparts[0], socket, msgText);
			return;
		}
		else{
			getUser(stripSequence(msgparts[0])).setLastMessage(msgText);//
		}

		User u;			//Used as a placeholder to add users to the online list
		int listLen;		//Used to hold the lenths of various user lists
		String message;		//Used to store messages to be sent
		User[] ulist;		//Used to store lists of users for parsing into chats
		String time;		//Used to store time stamps for chat starts

		switch(msgparts[1]){
		//Message from User (Post: Message, Timestamp, Message)
		//REACTION: Pass on the message to the group
			case "Post: Message":
				message= "Post: MessagePassOn\n";
				message+= stripSequence(msgparts[0])+ "\n";
				message+= msgparts[2]+"\n";
				message+= msgparts[3];
            super.sendAck(group, grpPort, msgparts[0], socket, msgText);
				super.send(message, group, grpPort, socket, userList.size(), msgText, null);
				break;

		//Request to leave (Post: EndChat, TimeStamp)
		//REACTION: remove from userslist, tell people they've left
			case "Post: EndChat":
				u=getUser(stripSequence(msgparts[0]));
				
				message= "Post: EndNotice\n";
				message+=u.name + "\n";
            
            userList.remove(u);
            
				message+= msgparts[2]+"\n";
				message+= userList.size();
            
				super.send(message, group, grpPort, socket, userList.size()+1, msgText, null);//+1 because of some missed ack shenanigans
            
				break;
			
			default:
				System.out.println(chatName+"did not understand "+ msgparts[1]);
		}
	}

	/** Retrieves desired user
	 *
	 * @param uname name of user desired
	 * @return the user
	 */
	private User getUser(String uname){
		for( User u: userList ){
			if (u.name.equals(uname)){
				return u;
			}
		}
		return null;
	}

	/** Checks if the received datagram was already received earlier from the sender
	 *
	 * @param sqnce the sequence identifier of the possibly duplicated packet
	 * @param msgText the message received previously
	 * @return true if duplicate message
	 */
	private boolean isDuplicate( String sqnce, String msgText ){
		String sq= stripSequence(sqnce);//shaves off the sequence digits
		User u= getUser(sq);//retrieves the user from the username
		return u.lastMessage.equals(msgText);
	}

	/** Extracts the username portion from client messages
	 *
	 * @param sq the message
	 * @return the username portion of the message
	 */
	private String stripSequence(String sq){
		String[] parts= sq.split("-");
		return parts[1];
	}
}