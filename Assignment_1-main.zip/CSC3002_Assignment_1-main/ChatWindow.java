//Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
//April 2021
//ChatWindow class for Chat Application

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.*;
import java.sql.Timestamp;
import java.util.Date;

/** ChatWindow class for Chat Application
 * @author Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
 * @version 1.0
 * @since 2021-04-12
 */
public class ChatWindow extends Client implements Runnable, ActionListener {

    /**
     * The username
     */
    String username;

    /**
     * The name of the chat created
     */
    String chatName;

    /**
     * The socket being created
     */
    MulticastSocket chatSocket;

    /**
     * The server's port
     */
    int serverPort;

    /**
     * The group address
     */
    InetAddress groupAddress;

    /**
     * The server address
     */
    InetAddress serverAddress;

    /**
     * The array of chat members present
     */
    String[] chatMembers;

    /**
     * The current timestamp
     */
    Date date;

    /**
     * Text field for actual messages
     */
    JTextArea textField;

    /**
     * Text field for sending messages at the bottom
     */
    JTextField typeBar;

    /**
     * The send message button
     */
    JButton send;

    /**
     * The leave chat button
     */
    JButton quit;

    /**
     * The last message, used for checking duplicates
     */
    String lastMessage = "";

    /**
     * The current message being displayed
     */
    String currentMessage;

    /**
     * Set to false if a button has been pressed to pause the run method
     */
    boolean CWButtonPressed = false;

    /**
     * Waiting for a confirmation message
     */
    boolean noConfYet=true;

    /**
     * The top panel
     */
    private JPanel top;

    /**
     * The centre panel
     */
    private JPanel centre;

    /**
     * The bottom panel
     */
    private JPanel bottom;

    /**
     * The left panel
     */
    private JPanel left;

    /**
     * The right panel
     */
    private JPanel right;

    /**
     * The text in the centre panel
     */
    private JScrollPane text;

    /**
     * The group name
     */
    private JLabel groupName;

    /**
     * Extra space to fill the left panel
     */
    private JLabel lspace;

    /**
     * Extra space to fill the right panel
     */
    private JLabel rspace;

    /**
     * Extra space to space the top panel appropriately
     */
    private JLabel topSpace;

    /**
     * Label to display the name of the user
     */
    private JLabel name;

    /**
     * All messages in the chat in one string to be printed in the centre panel
     */
    String chatting = "";

    /** Constructor
     *
     * @param port the port number used
     * @param groupAddress the groupAddress
     * @param username the username of the user
     * @param serverPort the server's port
     * @param serverAddress the server's InetAddress
     * @param chatName the name of the chat
     * @param chatMembers the array containing the members of the chat
     * @param ms the MulticastSocket used
     */
    public ChatWindow(int port, InetAddress groupAddress, String username, int serverPort, InetAddress serverAddress, String chatName, String[] chatMembers, MulticastSocket ms){ //use this when everything works; replaced now so it runs
        
        /////////////////////////////// HOME PAGE FRAME ///////////////////////////////
        
        super(port, groupAddress);
        
        System.out.println("CHAT WINDOW CONSTRUCTOR CALLED");
        System.out.println("Username: "+username);
        System.out.println("Local Port: "+port);
        System.out.println("Local Address: "+groupAddress.toString());
        System.out.println("Server Port: "+serverPort);
        
        setSize(super.WIDTH, super.HEIGHT);
        setBackground(HomePage.LBLUE);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); //rather use quit button
        setLayout(new BorderLayout());

        /////////////////////////////// INITIALISING VARIABLES ///////////////////////////////

        this.chatName = chatName;
        this.port = port;
        this.groupAddress = groupAddress;
        this.chatMembers = chatMembers;
        this.serverAddress=serverAddress;

        chatSocket=ms;

        date = new Date();

        /////////////////////////////// JPANELS ///////////////////////////////

        //Top
        top = new JPanel();
        top.setLayout(new BorderLayout());
        top.setBackground(super.LBLUE);
        add(top, BorderLayout.NORTH);

        //Middle
        centre = new JPanel();
        centre.setLayout(new BoxLayout(centre, BoxLayout.PAGE_AXIS));
        centre.setBorder(BorderFactory.createStrokeBorder(new BasicStroke(3.0f))); //black border
        add(centre, BorderLayout.CENTER);

        //Bottom
        bottom = new JPanel();
        add(bottom, BorderLayout.SOUTH);
        bottom.setBackground(super.LBLUE);

        //Left
        left = new JPanel();
        left.setBackground(super.LBLUE);
        add(left, BorderLayout.WEST);

        //Right
        right = new JPanel();
        right.setBackground(super.LBLUE);
        add(right, BorderLayout.EAST);

        /////////////////////////////// JLABELS ///////////////////////////////

        groupName = new JLabel(chatName);
        groupName.setFont(super.TB20);
        groupName.setForeground(Color.BLACK);
        groupName.setHorizontalAlignment(JLabel.CENTER);
        groupName.setVerticalAlignment(JLabel.CENTER);
        top.add(groupName, BorderLayout.CENTER);

        lspace = new JLabel("                 ");
        rspace = new JLabel("                 ");
        topSpace = new JLabel(" ");
        left.add(lspace);
        right.add(rspace);
        top.add(topSpace, BorderLayout.WEST);
        
        name = new JLabel(username + ":  ");
        name.setFont(super.TP14);
        name.setForeground(Color.BLACK);
        bottom.add(name, BorderLayout.WEST);

        /////////////////////////////// JTEXTFIELDS & JTEXTAREAS///////////////////////////////

        textField = new JTextArea(chatting); //adding string to panel
        textField.setEditable(false);

        typeBar = new JTextField(70);
        bottom.add(typeBar);
        

        /////////////////////////////// JSCROLLPANES ///////////////////////////////

        text = new JScrollPane(textField);
        centre.add(text);

        /////////////////////////////// JBUTTONS ///////////////////////////////

        send = new JButton("  SEND  ");
        send.setBackground(Color.RED);
        send.setForeground(Color.WHITE);
        send.setFont(super.TP14);
        bottom.add(send);
        send.addActionListener(this);

        quit = new JButton("QUIT");
        quit.setBackground(Color.BLACK);
        quit.setForeground(Color.WHITE);
        quit.setFont(super.TP14);
        top.add(quit, BorderLayout.EAST);
        quit.addActionListener(this);
        
        this.setVisible(true);

    }

    /**
     * Waiting for confirmation; loops until the message "Post: ConfirmChatOpen" is received
     */
    private void awaitConfirmation(){
    //This method will loop until we receive the message "Post: ConfirmChatOpen"
    //Then will set noConfYet to false and return
      while(noConfYet){
         System.out.println("in");
        byte[] buf = new byte[512];
        DatagramPacket conf = new DatagramPacket(buf, buf.length);
        
        try{
            chatSocket.receive(conf);
        }

        catch(IOException e){
            System.out.println("Timeout in awaitConfirmation()");
            continue;
        }
        
        
        serverAddress= conf.getAddress();
        serverPort= conf.getPort();
        
        String msgText= new String(conf.getData(), 0, conf.getLength());

        if(!(super.goodCheckSum(msgText))){
            continue;
        }

        msgText= super.stripCheckSum(msgText);
        
        this.lastMessage=msgText;//for duplicate tracking
        
        String[] msgParts= msgText.split("\n");
        
        System.out.println("MSGPARTS[1]: " +msgParts[1]);

        noConfYet= !(msgParts[1].equals("Post: ConfirmChatOpen"));//if this is the msg we're after, open the chat
        sendAck(serverAddress, conf.getPort(), msgParts[0], chatSocket, msgText);
      }
    
    }

    /** ActionListener for JFrame; reacts to buttons pressed
     *
     * @param e the action performed by the user in the GUI
     */
    public synchronized void actionPerformed(ActionEvent e) {
        String button = e.getActionCommand();

        CWButtonPressed = true;
        
        if(noConfYet){//buttons must only start working when confirmation is received
            return;
        }

        if(button.equals("  SEND  ")&& send.getBackground().equals(Color.RED)){
            String messageToSend = typeBar.getText();
            if(messageToSend.length() > 0){ //to make sure that they actually typed something
                send.setBackground(Color.GRAY); //turn back to red when the message is received

                String message= "Post: Message\n";

                long time = date.getTime();
                Timestamp timestamp = new Timestamp(time);

                String tStamp = "(" + timestamp.toString() + ")";

                message+= tStamp + "\n";//"Sent" Timestamp
                message+= messageToSend;//The actual message
                super.send(message, serverAddress, serverPort, chatSocket, 1, lastMessage);
            }
        }

        else if(button.equals("QUIT")){
        
            if(chatMembers.length<=1){//last member need not notify the server as it is already dead
               this.HasQuit=true;
               this.dispose();
               return;
            }
        
            String message=   "Post: EndChat\n";

            long time = date.getTime();
            Timestamp timestamp = new Timestamp(time);

            String tStamp = "(" + timestamp.toString() + ")";

            message+= tStamp + "\n";

            super.send(message, serverAddress, serverPort, chatSocket, 1, lastMessage);

            this.HasQuit = true;
            this.dispose();
        }

        revalidate();
        repaint();
        CWButtonPressed = false;
    }

    /**
     * Run method
     */
    public void run(){

        while(!(this.HasQuit)){
            while(!CWButtonPressed && !(this.Sending)){
                awaitConfirmation();
                
                try{
                  chatSocket.setSoTimeout(100);//the purpose of the timeout is so that the program doesn't block on the receive method
                                          //because other functions will need to use the socket
                }                          
                catch(SocketException e){//weird error
                    System.out.println("SocketException when setting timer in homepage run method");
                }
                
                this.Receiving=true;
                this.receive();
                this.Receiving=false;
                
                try{
                  Thread.sleep(500);//delays for half a second to give send methods a chance to start
                }
                catch(InterruptedException e){
                  System.out.println("Interrupted Exception when calling sleep in homepage's run method");
                }
            }
        }
        System.out.println("END OF CHAT THREAD");
        return;
    }

    /**
     * Receive method
     */
    public synchronized void receive(){
        //Involves the receipt and processing of all messages in this server

        if(this.Sending==true){return;}
        byte[] buf = new byte[512];
        DatagramPacket msg = new DatagramPacket(buf, buf.length);
        try{
        
            synchronized(chatSocket){
               chatSocket.receive(msg);
            }   
               
        }

        catch(IOException e){
            return;
        }
        
        String msgText= new String(msg.getData(), 0, msg.getLength());
        System.out.println("RECEIVE METHOD SUCCESSFULLY RECEIVED:\n" + msgText);
        
        

        if(!(super.goodCheckSum(msgText))){
            return;
        }
        
        

        msgText= super.stripCheckSum(msgText);
        String[] msgParts= msgText.split("\n");
        
        if(msgParts.length==1){
         return;//this triggers for ack messages, and prevents null pointers in the switch statement
        }

        if(msgText.equals(lastMessage)){
            System.out.println("DUPLICATE DETECTED:\n" +msgText);
            super.sendAck(serverAddress, serverPort, msgParts[0], chatSocket, msgText);
            return;
        }
        else{
            lastMessage= msgText;
        }

        String message;		//Used to store messages to be sent
        String time;		//Used to store time stamps for chat starts
        String sender;

        switch(msgParts[1]){
            case "Post: MessagePassOn":
                sender = msgParts[2];
                time = msgParts[3];
                message = msgParts[4];

                currentMessage = time + " " + sender + ": " + message+ "\n";
                textField.setText(textField.getText()+currentMessage);
                
                send.setBackground(Color.RED);
                typeBar.setText("");
                
                repaint();

                super.sendAck(serverAddress, serverPort, msgParts[0], chatSocket, msgText);

                break;

            case "Post: EndNotice":
                sender = msgParts[2];
                time = msgParts[3];

                String[] temp = new String[Integer.parseInt(msgParts[4])];
                int index = 0;

                for(String cm: chatMembers){
                    if(!(cm.equals(sender))){//if cm not the sender
                        temp[index] = cm;    //put them in the array
                        index++;             //and increment the index
                    }
                }

                chatMembers = temp;

                currentMessage = time + " " + sender + ": has left the chat!\n";
                
                textField.setText(textField.getText()+currentMessage);
                
                if(chatMembers.length<=1){
                  typeBar.setText("CHAT CLOSED AS ONLY ONE USER REMAINS");
                  send.setBackground(Color.GRAY);
                }

                revalidate();
                repaint();
                
                super.sendAck(serverAddress, serverPort, msgParts[0], chatSocket, msgText);

                break;

            default:
                System.out.println(chatName+" did not understand "+ msgParts[1]);
                super.sendAck(serverAddress, serverPort, msgParts[0], chatSocket, msgText);
        }
    }
}