//Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
//April 2021
//Abstract parent Client class for Chat Application

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Random;

/** Abstract parent Client class for Chat Application
 * @author Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
 * @version 1.0
 * @since 2021-04-03
 */
public abstract class Client extends JFrame {

   /** 
    * Boolean for Appendix A
    */
    final boolean messUpMyPackets=false;
   
    /** 
     * Random object for Appendix A
     */ 
    Random r;
    
    /**
     * Window width initially 1000
    */
    static final int WIDTH = 1000;
    /**
    *Window height initially 600
    */
    static final int HEIGHT = 600;
    /**
    *Big font
    */
    static final Font TB20 = new Font("Tahoma", Font.BOLD, 20);
    /**
    *Normal font
    */
    static final Font TP14 = new Font("Tahoma", Font.BOLD, 14);
    /**
    *First colour variation of blue
    */
    static final Color DBLUE = new Color(0, 0, 150);
    /**
    *Second colour variation of blue
    */
    static final Color LBLUE = new Color(0, 150, 255);
    /**
    *A key object to aid program flow
    */
    static final Object key= new Object();
    /**
    *Sending boolean to show state of sending
    */
    boolean Sending;
    /**
    *Receiving boolean to show state of receiving
    */
    boolean Receiving;
    /**
    *HasQuit boolean to show quitting 
    */
    boolean HasQuit;
    /**
    *port number of client
    */   
    int port;
    /**
    *address of the client
     */
    InetAddress address;
    /**
     * Sequence number starting from zero
    */
    int sequenceNumber = 0;
    
    /**
     * Constructor
    *@param port number
    *@param InetAddress as an address
     */

    public Client(int port, InetAddress address) {
        super("ChatHub");
        this.port = port;
        this.address = address;
    }
    /** 
     * Abstract receive method
     */
    public abstract void receive();

    ///////////////////////////////////SEND/////////////////////////////////
    //From E: server
    /** Sends the Datagram packet via a Datagram socket
    *
    * @param message the message being sent by the server
    * @param destAddress the destination address
    * @param destPort the destination port number
    * @param sourceSocket the source socket
    * @param numReceivers the number of receivers of this packet
    * @param lastMessage the last message sent
    * @return true if it was sent successfully
    */

    public synchronized boolean send (String message, InetAddress destAddress, int destPort,
                         DatagramSocket sourceSocket, int numReceivers, String lastMessage){ //changed to synchronized
        synchronized(sourceSocket){
        
           this.Sending=true;
           while(this.Receiving){//block while this happens else receive
               System.out.println("Blocking before sending:\n"+message+"--------"); 
               //BLOCK (EAS)
           }
           
           //NOTE FOR THE ABOVE WHILE-BLOCK: I blocked when either one is receiving as they share a send method. 
          
   
           message= sequenceNumber +"-"+HomePage.name + "\n" + message;//EAS added the \n and reordered this
           //adds sequenceNumber to Header
           
           message= calculateCheckSum(message) + " " + message; 
           //adds checkSum to Header
   
           System.out.println("SENDING:\n"+message);
   
           sequenceNumber++;
           
           
   
           DatagramPacket packet= new DatagramPacket
                   (message.getBytes(), message.getBytes().length, destAddress, destPort);
           //makes a new DatagramPacket containing the headered message for sending
           //to out destination

           int numAcks=0; //The number of receipt acknowledgements
           //We need this to equal the number of receivers
           
           
           
           if(messUpMyPackets){
               r= new Random();
               DatagramPacket corruptPacket;
               switch(r.nextInt()%5){//40% of packets are messed up
                  case 0://corrupt it
                     System.out.println("Corrupted Message Sent");
                     String corrupt= "AssemblyDereferencingSymbol bill y'all "+ message + "Cache money baabehhh";
                     corruptPacket= new DatagramPacket
      		               (corrupt.getBytes(), corrupt.getBytes().length, destAddress, destPort);
                     try{
         			      sourceSocket.send(corruptPacket);//Sends the packet to the enclosed address(es)
         		      }
         		      catch (IOException e){
         			      System.out.println("IO Exception when sending");
         			      System.exit(0);
         		      }
                     break;
                     
                  case 1://don't send it
                     System.out.println("Packet intentionally not sent");
                     break;
                  default:
                     try{
         			      sourceSocket.send(packet);//Sends the packet to the enclosed address(es)
         		      }
               		catch (IOException e){
               			System.out.println("IO Exception when sending");
               			System.exit(0);
               		}
               }
            }
            else{
         		try{
         			sourceSocket.send(packet);//Sends the packet to the enclosed address(es)
         		}
         		catch (IOException e){
         			System.out.println("IO Exception when sending");
         			System.exit(0);
         		}
            }

           int numLoops=0;//will be used to time out unending requests
           ArrayList<String> Acks= new ArrayList<String>(numReceivers);//used to check for duplicate acks
           //tracks all Acks "so far" in the loop below
           //We use this to check if a received Ack is a duplicate
           //Messages can be duplicated in transit after all
   
           try{
               //The below waits for acknowledgement from all users
               //the message was sent to
               //We already have from the people in Acks
   
               byte[] buf = new byte[512];
   
               DatagramPacket acknowledgement=
                       new DatagramPacket(buf, buf.length);
   
               String msgText;//Used below to convert received messages to strings
   
               while(numAcks<numReceivers){
                   sourceSocket.setSoTimeout(500);
                   
   
                   numLoops++;//A check for how many times we've been here before
   
                   if(numLoops==50){//EAS changed to numloops from numresends
                       System.out.println("A user was timed out Client.send");
                       
                       //HomePage.HPSending = false;//sending ends for homepage
                       //ChatWindow.CWSending = false;//sending ends for chatwindow
                       this.Sending=false;
                       return false;
                   }
   
   
                   sourceSocket.receive(acknowledgement);
                   
                   //fills receiving DataGram with what is hopefully an acknowledgement
   
                   msgText= new String
                           (acknowledgement.getData(), 0, acknowledgement.getLength());
                           
                   System.out.println("RECEIVED WHEN EXPECTING ACK:\n"+ msgText+"\n------");
                   //System.out.println("I got "+msgText+ "When sending" +message);
   
                   if(!(goodCheckSum(msgText))){//bad checksum
                       continue;
                   }
                   
                   if(lastMessage.equals(stripCheckSum(msgText))){
                        String[] msgparts= stripCheckSum(msgText).split("\n");
                        sendAck(acknowledgement.getAddress(), acknowledgement.getPort(), msgparts[0], sourceSocket, msgText);
                   }
   
                   if(isAcknowledgement(msgText)&&
                           !(Acks.contains(msgText))){
                       //Checks if this is an ack and if it's not a duplicate
                       //Adds the received message to Acks
                       
                       //HomePage.HPSending = false;//sending ends for homepage
                       //ChatWindow.CWSending = false;//sending ends for chatwindow
                       
                       this.Sending=false;
   
                       Acks.add(msgText);
                       numAcks++;//Once we have enough unique acks, the loop ends
                   }
                  else{
                      //return resend(packet, sourceSocket, numReceivers-numAcks, Acks, numLoops, numAcks, message, lastMessage);
                      continue;
                  }
               }
               //HomePage.HPSending = false;//sending ends for homepage
               //ChatWindow.CWSending = false;//sending ends for chatwindow
               this.Sending=false;
                  
           }
           catch(SocketException e){ //changed to this
               System.out.println("Socket exception when sending message");
               //EAS: Did these below as cleanup
               //HomePage.HPSending = false;//sending ends for homepage
               //ChatWindow.CWSending = false;//sending ends for chatwindow
               this.Sending=false;
           }
           catch(IOException e){//Socket times out
               //numResends++;
               System.out.println("ACK EXPECTED FOR:\n"+message+ "\nNOW RESENDING");
               return resend(packet, sourceSocket, numReceivers-numAcks, Acks, numLoops, numAcks, message, lastMessage);//, numResends);//EAS changed to numLoops
           }
   
           return true;
       }
    }
    /** Resends the Datagram packet if original send fails
    *
    * @param packet the DatagramPacket being sent
    * @param sourceSocket the source socket
    * @param numReceivers the number of receivers of this packet
    * @param Acks the number of acknowledgements already received successfully in response to previous sends
    * @param numLoops the number of times the message has been sent
    * @param numAcks the number of acknowledgements expected to be received
    * @param message the message being sent
    * @param lastMessage the message sent previously
    * @return true if it was sent successfully
    */
    public synchronized boolean resend
            (DatagramPacket packet, DatagramSocket sourceSocket, int numReceivers, ArrayList<String> Acks, int numLoops,
             int numAcks, String message, String lastMessage){//,int numResends){ //changed to synchronized EAS: Changed to NUMLOOOOOOOOOOPS
        //Note: NumReceivers= NumReceivers-numAcks.
        //Corresponds to how many receivers we still need acks from

      System.out.println("RESENDING:\n"+message);
      synchronized(sourceSocket){
        numAcks=0; //The number of receipt acknowledgements
        //We need this to equal the number of receivers
        
        if(messUpMyPackets){
               r= new Random();
               DatagramPacket corruptPacket;
               switch(r.nextInt()%5){//40% of packets are messed up
                  case 0://corrupt it
                     System.out.println("Corrupted Message Sent");
                     String corrupt= "AssemblyDereferencingSymbol bill y'all "+ message + "Cache money baabehhh";
                     corruptPacket= new DatagramPacket
		                  (corrupt.getBytes(), corrupt.getBytes().length, packet.getAddress(), packet.getPort());
                     try{
         			      sourceSocket.send(corruptPacket);//Sends the packet to the enclosed address(es)
         		      }
         		      catch (IOException e){
         			      System.out.println("IO Exception when sending");
         			      System.exit(0);
         		      }
                     break;
                     
                  case 1://don't send it
                     System.out.println("Packet intentionally not sent");
                     break;
                  default:
                     try{
         			      sourceSocket.send(packet);//Sends the packet to the enclosed address(es)
         		      }
               		catch (IOException e){
               			System.out.println("IO Exception when sending");
               			System.exit(0);
               		}
               }
            }
        else{
         	try{
         		sourceSocket.send(packet);//Sends the packet to the enclosed address(es)
         	}
         	catch (IOException e){
         		System.out.println("IO Exception when sending");
         		System.exit(0);
         	}
        }


        try{
            //The below waits for acknowledgement from all users
            //the message was sent to
            //We already have from the people in Acks

            byte[] buf = new byte[512];

            DatagramPacket acknowledgement=
                    new DatagramPacket(buf, buf.length);

            String msgText;//Used below to convert received messages to strings

            while(numAcks<numReceivers){
                sourceSocket.setSoTimeout(500);
                //2 seconds provisionally-- Must be >RTT

                numLoops++;//A check for how many times we've been here before

                if(numLoops==50){
                    System.out.println("A server was timed out Client.resend");
                    System.out.println("EXPECTED ACK FOR:\n"+message+"\n-----");
                    
                    //HomePage.HPSending = false;//sending ends for homepage
                    //ChatWindow.CWSending = false;//sending ends for chatwindow
                     this.Sending=false;
                    
                    return false;
                }


                sourceSocket.receive(acknowledgement);
                //fills receiving DataGram with what is hopefully an acknowledgement

                msgText= new String
                        (acknowledgement.getData(), 0, acknowledgement.getLength());

                if(!(goodCheckSum(msgText))){//bad checksum
                    continue;
                }
                
               if(lastMessage.equals(stripCheckSum(msgText))){
                     String[] msgparts= stripCheckSum(msgText).split("\n");
                     sendAck(acknowledgement.getAddress(), acknowledgement.getPort(), msgparts[0], sourceSocket, msgText);
               }

                if(isAcknowledgement(msgText)&&
                        !(Acks.contains(msgText))){
                    //Checks if this is an ack and if it's not a duplicate
                    //Adds the received message to Acks

                    Acks.add(msgText);
                    numAcks++;//Once we have enough unique acks, the loop ends
                    
                    //Putting these here because clients only need 1 ack
                    //HomePage.HPSending = false;//sending ends for homepage
                    //ChatWindow.CWSending = false;//sending ends for chatwindow
                    this.Sending=false;

                }
            }
            //System.out.println("I'm here");
            //HomePage.HPSending = false;//sending ends for homepage
            //ChatWindow.CWSending = false;//sending ends for chatwindow
            this.Sending=false;
        }
        catch(SocketException e){ //changed to this
            System.out.println("Socket exception when sending message");
            //EAS: Did these below as cleanup
            //HomePage.HPSending = false;//sending ends for homepage
            //ChatWindow.CWSending = false;//sending ends for chatwindow
            this.Sending=false;
        }
        catch(IOException e){//Socket times out
           
            return resend(packet, sourceSocket, numReceivers-numAcks, Acks, numLoops, numAcks, message, lastMessage);//, numResends);// not numResends!!!
        }

        return true;
      }
    }

    ///////////////////////////////////////Acknowledgement////////////////////////////////
    /** Sends acknowledgements
    *
    * @param destAddr the destination address
    * @param destPort the destination port
    * @param sqNum the sequence number
    * @param sourceSocket the source socket
    * @param message the message that was received successfully
    */
    public synchronized void sendAck
            (InetAddress destAddr, int destPort, String sqNum, DatagramSocket sourceSocket, String message){
	   //sends an error message-- similar to an ack, these do not take confirmations
		//changed to synchronized
      sqNum=sqNum.trim();//you never know...
		String ack= sqNum+ " Post: Received";
      ack= calculateCheckSum(ack)+ " "+ ack +"\n"+ HomePage.name;
      DatagramPacket ackGram;
      r=new Random();
      if(messUpMyPackets){
         switch(r.nextInt()%5){
            case 0:
               //corrupt it
               System.out.println("ACK INTENTIONALLY CORRUPTED");
               ack+= "I like big bytes and I cannot lie";
               ackGram= 
         		new DatagramPacket(ack.getBytes(), ack.getBytes().length, destAddr, destPort);
         		try{
         			sourceSocket.send(ackGram);
                  System.out.println("ACK SENT: \n"+ ack +"\nACKING FOR:\n"+message);
         		}
         		catch(IOException e){
         			System.out.println("IO Exception");
         			System.exit(0);
         		}
               break;

            case 1:
               System.out.println("ACK INTENTIONALLY DISCARDED");
               //don't send it
               break;
            default:
               //proceed as normal
               ackGram= 
         		new DatagramPacket(ack.getBytes(), ack.getBytes().length, destAddr, destPort);
         		try{
         			sourceSocket.send(ackGram);
                  System.out.println("ACK SENT: \n"+ ack +"\nACKING FOR:\n"+message);
         		}
         		catch(IOException e){
         			System.out.println("IO Exception");
         			System.exit(0);
         		}

         }
      }
      else{
   		ackGram= 
   		new DatagramPacket(ack.getBytes(), ack.getBytes().length, destAddr, destPort);
   		try{
   			sourceSocket.send(ackGram);
            System.out.println("ACK SENT: \n"+ ack +"\nACKING FOR:\n"+message);
   		}
   		catch(IOException e){
   			System.out.println("IO Exception");
   			System.exit(0);
   		}
      }
    }
    
    /** Checks if the format of the message is that of an acknowledgement
    *
    * @param msgText the message being checked
    * @return true if it was recognised as an acknowledgement
    */
    public boolean isAcknowledgement(String msgText){
	//checks if the format of the message is that of an acknowledgement
	// Ack format: <checkSum> <sqnum> Post: Received
		String sq= Integer.toString(sequenceNumber-1);
      System.out.println("CHECKING IF RECEIVED MESSAGE IS AN ACK:");
		if(Client.stripCheckSum(msgText).equals(sq+ "-"+ HomePage.name+" Post: Received")){
         System.out.println(msgText+ "\n...WAS recognized as an ack");
			return true;
		}
		else{
         System.out.println(stripCheckSum(msgText)+ "\n...WAS NOT recognized as an ack as it does not equal...\n"+ sq+ "-"+ HomePage.name+ " Post: Received\n----------" );
			return false;
		}
	}
    
    /** An alternative version of the method to check if the format of the message is that of an *acknowledgement
    * @param msgText the message being checked
    * @return true if it was recognised as an acknowledgement
    */
   public boolean isAcknowledgement2(String msgText){//need for sendfor which uses normal sqnums
	//checks if the format of the message is that of an acknowledgement
	// Ack format: <checkSum> <sqnum> Post: Received
		String sq= Integer.toString(sequenceNumber-1);
      System.out.println("CHECKING IF RECEIVED MESSAGE IS AN ACK:");
		if(Client.stripCheckSum(msgText).equals(sq+" Post: Received")){
         System.out.println(msgText+ "\n...WAS recognized as an ack");
			return true;
		}
		else{
         System.out.println(stripCheckSum(msgText)+ "\n...WAS NOT recognized as an ack as it does not equal...\n"+ sq+" Post: Received\n----------" );
			return false;
		}

	}
   
   
    

    //////////////////////////////CHECKSUM/////////////////////////////////////
    //From E: server
//<<<<<<< HEAD
//public int calculateChecksum(String message){
//=======
   /** Calculates the check sum used for error-checking. Adds up all integer values of the letters in the message
   *
   * @param message the message being calculated
   * @return the check sum value
   */
    public static int calculateCheckSum(String message){

        //message: The message that would be parsed to send-- checksum made for error-checking
        //This method adds up all the integer values of the letters in the message string
        //It is used in error-detecting
        //System.out.println(message);
        char[] msg= message.toCharArray();
        int sum=0;
        int j;
        for( char i: msg){
            j=i;//Idk for conversions
            sum+=j;//Might need to convert char to int first idk
        }
        return sum;
    }

    /** Returns true if check sum matches the message
    *
    * @param msgText the message being checked for errors
    * @return true if check sum matches the message
    */
    public static boolean goodCheckSum(String msgText){
        //returns true if checksum matches message
        String[] sep= separateChecksum(msgText);//{Checksum, restOfMessage}
        try{
            int foundCheckSum= Integer.parseInt(sep[0]);
        }
        catch(NumberFormatException e){
         return false;
        }
        if(calculateCheckSum(sep[1])
                !=Integer.parseInt(sep[0]))
        {
            return false;//checksum digit != calculated checksum
        }

        return true;
    }

    //////////////////////////////CHECKSUM/////////////////////////////////////
   
   
    //<<<<<<< HEAD
    //	public  String stripCheckSum(String msgText){
    //=======
    /** Strips the check sum from the rest of the message
    *
    * @param msgText the message with the check sum included
    * @return the message without the check sum
    */
        public static String stripCheckSum(String msgText){
    
            //removes checksum from a received message
            return separateChecksum(msgText)[1];
        }

        //<<<<<<< HEAD
    //	public String[] separateChecksum(String msgText){
    //=======
        /** Splits message into check sum and message
        *
        * @param msgText the message being split
        * @return an array of Strings with the message separated from the check sum value
        */  
        public static String[] separateChecksum(String msgText){
            //splits msg into checksum and msg
            String[] checksumAndMSG= msgText.split(" ",2);

            return checksumAndMSG;
        }
        /**  isDuplicate make sure that the message being received is not a duplicate of the last message
        *@param lastMessage is a string containing the last message that was sent
        *@param msgTextI a string of the current message that must be compared
        *@return a boolean that states if the two massage are are the same
        */
        
    public boolean isDuplicate( String lastMessageI, String msgTextI ){
        //Checks if the received datagram was already received earlier from the sender


        return (lastMessageI.equals(msgTextI));
      
    }
}
