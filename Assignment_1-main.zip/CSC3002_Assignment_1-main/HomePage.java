//Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
//April 2021
//HomePage class for Chat Application

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.*;
import java.sql.Timestamp;
import java.util.Date;

/** HomePage class for Chat Application
 * @author Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
 * @version 1.0
 * @since 2021-04-12
 */
public class HomePage extends Client implements Runnable, ActionListener {

    /////////////////////////////// VARIABLES ///////////////////////////////

    /**
     * The top panel
     */
    private JPanel topPanel;

    /**
     * The centre panel
     */
    private JPanel centrePanel;

    /**
     * The bottom panel
     */
    private JPanel bottomPanel;

    /**
     * The left panel
     */
    private JPanel leftPanel;

    /**
     * The right panel
     */
    private JPanel rightPanel;

    /**
     * The login panel
     */
    private JPanel loginPanel;

    /**
     * The list panel
     */
    private JPanel listPanel;

    /**
     * The start chatting button
     */
    private JButton startChatting;

    /**
     * The login button
     */
    private JButton login_button;

    /**
     * The refresh button
     */
    private JButton refresh;

    /**
     * The quit button
     */
    private JButton quit;

    /**
     * The confirm button
     */
    private JButton confirm;

    /**
     * The title label
     */
    private JLabel title;

    /**
     * The space in left panel label
     */
    private JLabel lspace;

    /**
     *The space in right panel label
     */
    private JLabel rspace;

    /**
     * The first login space label
     */
    private JLabel loginspace;

    /**
     * The second login space label
     */
    private JLabel loginspace2;

    /**
     * The login label
     */
    private JLabel login;

    /**
     * The group name label
     */
    private JLabel groupNameLabel;

    /**
     * The user name text field
     */
    private JTextField username;

    /**
     * The group name text field
     */
    private JTextField groupName;

    /**
     * The list scroll panel
     */
    private JScrollPane list;

    /**
     * User name
     */
    static String name="";

    /**
     * ArrayList of all the buttons representing currently online users
     */
    private ArrayList<JButton> onlineUsers = new ArrayList<JButton>();

    /**
     * ArrayList of members selected for a chat
     */
    ArrayList<String> members = new ArrayList<String>();

    /**
     * Boolean to determine if a button was pressed
     */
    boolean HPButtonPressed = false;

    /**
     * The socket being created
     */
    DatagramSocket socket0;

    /**
     * The hostname
     */
    String hostname;

    /**
     * The server's port
     */
    int portS;

    /**
     * The server�s address
     */
    InetAddress addressS;

    /**
     * The last message, used for checking duplicates
     */
    String lastMessage;

    /** Constructor
     *
     * @param port the port number used
     * @param address the client�s InetAddress
     * @param socket0 the datagramSocket used
     * @param addressS the server's address
     * @param portS the port's address
     */
    public HomePage(int port, InetAddress address, DatagramSocket socket0, InetAddress addressS, int portS) { //use when hostname, port and address are sorted

        /////////////////////////////// HOME PAGE FRAME ///////////////////////////////
       super(port, address);
        setSize(super.WIDTH, super.HEIGHT);
        //not maximising screen in case people have smaller screens then the sizes will be an issue
        setBackground(super.LBLUE);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); //rather use quit button so it can call the disconnect messages
        setLayout(new BorderLayout());

        /////////////////////////////// VARIABLES ///////////////////////////////
      
        this.socket0 = socket0;
        this.lastMessage = "";
        sequenceNumber = 0;
        this.portS=69;
        this.addressS = addressS;
        this.portS = portS;

        

        /////////////////////////////// JPANELS ///////////////////////////////

        //Top
        topPanel = new JPanel();
        topPanel.setBackground(super.LBLUE);
        add(topPanel, BorderLayout.NORTH);

        //Middle
        centrePanel = new JPanel();
        centrePanel.setBorder(BorderFactory.createStrokeBorder(new BasicStroke(3.0f))); //black border

        //Login
        loginPanel = new JPanel();
        loginPanel.setLayout(new GridBagLayout());
        setLocationRelativeTo(null);
        loginPanel.setBackground(super.LBLUE);
        add(loginPanel, BorderLayout.CENTER);

        //Bottom
        bottomPanel = new JPanel();
        add(bottomPanel, BorderLayout.SOUTH);
        bottomPanel.setBackground(super.LBLUE);

        //Left
        leftPanel = new JPanel();
        leftPanel.setBackground(super.LBLUE);
        add(leftPanel, BorderLayout.WEST);

        //Right
        rightPanel = new JPanel();
        rightPanel.setBackground(super.LBLUE);
        add(rightPanel, BorderLayout.EAST);

        /////////////////////////////// JLABELS ///////////////////////////////

        //Title
        title = new JLabel();
        title.setFont(super.TB20);
        title.setForeground(Color.BLACK);

        //Login Instruction
        login = new JLabel("Please enter your username: ");
        login.setFont(super.TB20);
        login.setForeground(Color.WHITE);
        loginPanel.add(login);

        //Spaces
        lspace = new JLabel("                 ");
        rspace = new JLabel("                 ");
        loginspace = new JLabel("                      ");
        loginspace2 = new JLabel("                      ");
        leftPanel.add(lspace);
        rightPanel.add(rspace);
        loginPanel.add(loginspace);

        groupNameLabel = new JLabel("  Please enter your chat name:  ");
        title.setFont(super.TB20);
        title.setForeground(Color.BLACK);

        /////////////////////////////// JTEXTFIELDS ///////////////////////////////

        username = new JTextField(20);
        loginPanel.add(username);
        loginPanel.add(loginspace2);

        groupName = new JTextField(20);

        /////////////////////////////// JSCROLLPANES ///////////////////////////////

        listPanel = new JPanel();
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.PAGE_AXIS));
        list = new JScrollPane(listPanel);
        list.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        list.setPreferredSize(new Dimension(853, 474));
        centrePanel.add(list);

        /////////////////////////////// JBUTTONS ///////////////////////////////

        //Login
        login_button = new JButton("  ENTER  ");
        login_button.setBackground(Color.RED);
        login_button.setForeground(Color.WHITE);
        login_button.setFont(super.TP14);
        loginPanel.add(login_button);
        login_button.addActionListener(this);
        
        

        //Start
        startChatting = new JButton("  START CHATTING!  ");
        startChatting.setBackground(Color.RED);
        startChatting.setForeground(Color.WHITE);
        startChatting.setFont(super.TP14);
        startChatting.addActionListener(this);

        refresh = new JButton("  REFRESH  "); //used to ask server the updated online list
        refresh.setBackground(Color.ORANGE);
        refresh.setForeground(Color.WHITE);
        refresh.setFont(super.TP14);
        refresh.addActionListener(this);

        quit = new JButton("  QUIT  "); //disconnect user and end program
        quit.setBackground(Color.BLACK);
        quit.setForeground(Color.WHITE);
        quit.setFont(super.TP14);
        bottomPanel.add(quit);
        quit.addActionListener(this);

        confirm = new JButton("  CONFIRM  ");
        confirm.setBackground(Color.RED);
        confirm.setForeground(Color.WHITE);
        confirm.setFont(super.TP14);
        confirm.addActionListener(this);
    }

    /** ActionListener for JFrame; reacts to buttons pressed
     *
     * @param e the action performed by the user in the GUI
     */
    public synchronized void actionPerformed(ActionEvent e) {
        HPButtonPressed = true;
        
        String button = e.getActionCommand();
        String NewMessage;
        String people = "";

        if (button.equals("  ENTER  ")) {
            name = username.getText();
            name = name.trim();
            
            if (name.length() < 1 || name.length() > 20) {
               if(name.length() > 20) {
                   username.setText("Please limit to 20 characters or less.");
               }   
            }
            
            else{
               name = username.getText();
               name = name.trim();
               
               NewMessage="\nGet: MembersList\nINITIAL";
               NewMessage=NewMessage+ "\n"+name+"\n";
               people = this.sendFor(NewMessage, addressS, portS, socket0,1,false);
   
               System.out.println("People:\n"+people);
               if(!(DuplicateCheck(people, name))){
                  if (!(people.equals(""))) {
                     addUsers(people);
                   }
   
                  else if(people.equals("Not able to perform this action")){
                      listPanel.add(new JLabel("Unable to load online users. Please refresh."));
                  }
      
                  else {
                          listPanel.add(new JLabel("No one is currently online."));
                  }
      
                 this.remove(loginPanel);
   
   
                 NewMessage = "Post: Join\n";
                 NewMessage = NewMessage + name + "\n";
                    super.send(NewMessage, addressS, portS, socket0,1,lastMessage);
   
                 add(centrePanel, BorderLayout.CENTER);
                 title.setText("Welcome " + name + "! Who would you like to chat with?");
                 topPanel.add(title);
                 bottomPanel.remove(quit);
                 bottomPanel.add(refresh);
                 bottomPanel.add(quit);
                 this.Sending= false;
               }
               else{
                     username.setText("Username Taken");
               }
            }              
        }

        else if (button.equals("  REFRESH  ")) {
        
            listPanel.removeAll();
            
            
            members.clear();
            bottomPanel.remove(startChatting);

            
            quit.removeActionListener(this);
            quit.setBackground(Color.GRAY);
            refresh.removeActionListener(this);
            refresh.setBackground(Color.GRAY);

           NewMessage="\nGet: MembersList\nREFRESH";
             NewMessage=NewMessage+"\n"+ name+"\n";
            people = this.sendFor(NewMessage, addressS, portS, socket0,1,true );
        
          if (!(people.equals(""))) {
                     addUsers(people);
          }

          else if(people.equals("Not able to perform this action")){
              listPanel.add(new JLabel("Unable to load online users. Please refresh."));
          }

          else {
                    listPanel.add(new JLabel("No one is currently online."));
          }

          quit.addActionListener(this);
          quit.setBackground(Color.BLACK);
          refresh.addActionListener(this);
          refresh.setBackground(Color.ORANGE);


        }

        else if (button.equals("  QUIT  ")) {

            if (name != null) { //if not, no connection was set up and they exited from the login panel
                NewMessage="Get: End\n"; // tells server this person is now offline
               super.send(NewMessage, addressS, portS, socket0, 1,lastMessage);
            }

            this.HasQuit = true;
            System.exit(0);
        }

        else if (button.equals("  START CHATTING!  ")) {
            bottomPanel.remove(startChatting);
            bottomPanel.remove(refresh);
            bottomPanel.remove(quit);
            bottomPanel.add(groupNameLabel);
            bottomPanel.add(groupName);
            bottomPanel.add(confirm);
            bottomPanel.add(quit);
        }

        else if(button.equals("  CONFIRM  ")){

            String gName = groupName.getText();

            if(gName.length() > 0 && gName.length() < 21){
                NewMessage="Post: NewChat\n";// asks server to create a new chat
                
                members.add(username.getText());
                
                NewMessage=NewMessage+gName+"\n";
                NewMessage=NewMessage+ members.size()+"\n";
                Date date= new Date();
                long time = date.getTime();
                Timestamp timestamp = new Timestamp(time);

                NewMessage = NewMessage + timestamp.toString() + "\n";

                //adds members in the new chat to the server
                for (String m:members){
                    NewMessage=NewMessage+ m+"\n";
                }
                 super.send(NewMessage, addressS, portS, socket0,1, lastMessage);

                bottomPanel.remove(quit);
                bottomPanel.remove(groupNameLabel);
                bottomPanel.remove(groupName);
                bottomPanel.remove(confirm);
                bottomPanel.add(refresh);
                bottomPanel.add(quit);

                for(JButton j : onlineUsers){
                    if(j.getBackground().equals(Color.GREEN)){
                        j.setBackground(super.DBLUE);
                    }
                }

                groupName.setText("");
                members.clear();
            }

            else if(gName.length() > 20) { //username too long
                groupName.setText("Please limit to 20 characters or less.");
            }
        }

        else { //pushed a user to add to chat

            //finding the button in the list of buttons to change the colour
            for (JButton j : onlineUsers) {
                if (j.getText().equals(button.toString())) {
                     if(j.getBackground().equals(super.DBLUE)){
                         members.add(button.toString()); //add user to arraylist of chat members
                         j.setBackground(Color.GREEN);
                     }
                    else{
                          members.remove(button.toString());
                          j.setBackground(super.DBLUE);
                    }
                }
            }

            if (members.size() == 1) { //if it's the first user chosen, the start chatting button will appear
                bottomPanel.remove(quit);
                bottomPanel.add(startChatting);
                bottomPanel.add(quit);
            }
            if (members.size()==0){
                bottomPanel.remove(startChatting);
            }
        }

        HPButtonPressed = false;
        this.revalidate();
        this.repaint();
    }

    /** addUsers takes a string with user names, add them to a array of users and creates a member button for each name
     *
     * @param people a string of usernames separated by �\n�
     */
    private void addUsers(String people){
        onlineUsers.clear();
        String[] ppl = people.split("\n");
       
        Arrays.sort(ppl); //sorts them in alphabetical order

        int panelHeight = 0; //going to increase the height of the list panel if the list of online users become too large

        for (String s : ppl) {
            JButton j = new JButton(s);
            j.setMinimumSize(new Dimension(10, 30));
            j.setFont(super.TP14);
            j.setForeground(Color.WHITE);
            j.setBackground(super.DBLUE);
            j.setHorizontalAlignment(SwingConstants.CENTER);
            j.setVerticalAlignment(SwingConstants.CENTER);
            j.setAlignmentX(Component.CENTER_ALIGNMENT);
            listPanel.add(j); //add user button to list panel
            j.addActionListener(this);
            onlineUsers.add(j); //adding user to online users arraylist used to access the buttons pushed

            JLabel space = new JLabel(" "); //making space between user buttons
            space.setMinimumSize(new Dimension(1, 10));
            space.setHorizontalAlignment(SwingConstants.CENTER);
            space.setVerticalAlignment(SwingConstants.CENTER);
            listPanel.add(space);
            panelHeight += 40; //adding 40 to the height to keep track in case it needs to be increased because the online user list is too long
        }

        if (panelHeight > 600) { //increase height of panel because there are a lot of users - enables the scrollbar
            listPanel.setPreferredSize(new Dimension(500, panelHeight));
        }
    }

    /** DuplicateCheck compares a username with the a list of given usernames to find out if it is a unique username
     *
     * @people a string of usernames separated by �\n�
     * @param uname the username entered in by the user
     */
    private boolean DuplicateCheck(String people, String uname){
        String[] ppl = people.split("\n"); //split into an array of users

        for (String c : ppl) { //checking for duplicates
            System.out.println("||"+ c+ "... vs ..."+ uname+"||");
            if (c.equals(uname)) {
                return(true);
            }
        }

        return false;
    }

    /**
     * Receive method that will receive a datagram message and react according to what message was received
     */
    public synchronized void receive(){
		byte[] buf = new byte[512];
      
      this.Receiving=true;
      
      while(this.Sending||HPButtonPressed){
         //do nothing
      }

		DatagramPacket msg= new DatagramPacket(buf, buf.length);

		try{
         synchronized(socket0){
			   socket0.receive(msg);
         }
		}
      
      

		catch (IOException e){         
         return;
		}


		String msgText= new String(msg.getData(), 0, msg.getLength());
      
      System.out.println("RECEIVE FUNCTION CALLED AND IS PROCESSING:\n"+msgText+"\n----------");

		if(!(super.goodCheckSum(msgText))){
			return;
		}

		msgText= super.stripCheckSum(msgText);
		String[] msgparts= 
			msgText.split("\n");
         
      if(msgparts.length==1){
         return;
      }
		
		if(super.isDuplicate(lastMessage,msgText)){
         System.out.println("DUPLICATE IN CLIENT:\n"+msgText);
			this.sendAck(msg.getAddress(), msg.getPort(), msgparts[0], socket0, msgText);
			return;
		}
		else{
			lastMessage = msgText;
		}

		int listLen;		//Used to hold the lenths of various user lists
		String NewMessage;	//Used to store messages to be sent
		String chatName;	//Used to store chatnames for "create chat" cmds
		String[] chatMembers;//Used to store lists of users for parsing into chats
		String time;		//Used to store time stamps for chat starts
      int grpPortNum;
      int srvPortNum;
      MulticastSocket ms=null;
      InetAddress grpAddr=null;

      
		switch(msgparts[1]){
            
         //Who is available to chat with (Post: AvailableMembers, ListLength, OnlineUsers)
		   //REACTION: Send an "AvailabilityList" message
         case "Post: AvailableMembers":
            String people="";
            for(int i = 3; i < (Integer.parseInt(msgparts[2])+3); i++){
               if (!((this.name).equals(msgparts[i]))){
               people= people +msgparts[i]+ "\n";
              }                
            }
            if (!(people=="")) { //if non-empty list
               addUsers(people);
            }

            else {
               listPanel.add(new JLabel("No one is currently online."));
            }

            
            this.sendAck
					(msg.getAddress(), msg.getPort(), msgparts[0], socket0, msgText);

				

				break;
            
         case "Post: ConnectChat"  :
            chatName= msgparts[2];
				listLen= Integer.parseInt(msgparts[3]);
				chatMembers= new String[listLen];
            
				time= msgparts[4+listLen];
            
            try{
               grpAddr= InetAddress.getByName(msgparts[5+listLen]);
            }
            catch(UnknownHostException e){
               System.out.println("Could not initialize group address at: "+ msgparts[5+listLen]);
            }
            
            grpPortNum = Integer.parseInt(msgparts[6+listLen]);
            srvPortNum = Integer.parseInt(msgparts[7+listLen]);

				for(int i=4; i<4+listLen; i++){					
                     chatMembers[i-4] = msgparts[i];
				}
            
            try{
               ms= new MulticastSocket(grpPortNum);
               ms.setTimeToLive(255);
               ms.joinGroup(grpAddr);
            }
            catch(SocketException e){
               System.out.println("Error setting up the multicast socket in homepage for "+chatName);
            }   
            catch(IOException e){
               System.out.println("Error setting up the multicast socket in homepage for "+chatName);
            }   
            
            
            (new Thread(new ChatWindow(grpPortNum, grpAddr, name, srvPortNum, addressS, chatName, chatMembers, ms))).start();
            super.sendAck(msg.getAddress(), msg.getPort(), msgparts[0], socket0, msgText);
            
            break;
		}
	}


    /** sendFor sends the Datagram packet, asking for member list from server, via a Datagram socket
     *
     * @param msg the message being sent by the server
     * @param destAddress the destination address
     * @param destPort the destination port number
     * @param sourceSocket the source socket
     * @param numReceivers the number of receivers of this packet
     * @param isRefresh boolean to indicate if this is a refresh request for the member list
     * @return a string containing the current member list from the server
     */
    public String sendFor(String msg, InetAddress destAddress, int destPort,
	 DatagramSocket sourceSocket, int numReceivers, boolean isRefresh){
      String msgText="";
      synchronized(key){
         this.Sending=true;
         
         String message=msg;
         boolean gotAck=false;
         
         String people="";
   
         if(name.equals("")){
   		   message= sequenceNumber + " " + message;
         }
         else{
            message= sequenceNumber +"-"+  name+ " " + message;
         }
   		//adds sequenceNumber to Header
         
         message= super.calculateCheckSum(message) + " " + message;
   		//adds checkSum to Header
   
   		sequenceNumber++;
   		
   		DatagramPacket packet= new DatagramPacket
   		(message.getBytes(), message.getBytes().length, destAddress, destPort);
   
   		int numAcks=0; //The number of receipt acknowledgements
   		//We need this to equal the number of receivers
   
   		try{
   			sourceSocket.send(packet);
            System.out.println("SENDING:\n"+message);
   
   		}
   		catch (IOException e){
   			System.out.println("IO Exception when sending");
   			System.exit(0);
   		}
         
   		int numLoops=0;
   		ArrayList<String> Acks= new ArrayList<String>(numReceivers);
   
   		try{
   			//The below waits for acknowledgement from all users 
   			//the message was sent to
   			//We already have from the people in Acks
   
   			byte[] buf = new byte[512];
   
   			DatagramPacket acknowledgement=
   				new DatagramPacket(buf, buf.length);
            
   			while(numAcks<numReceivers){
            
            
   			  sourceSocket.setSoTimeout(500);             
              
              numLoops++;
   
   			  
   			  sourceSocket.receive(acknowledgement);
   				
   			  msgText= new String
   				   (acknowledgement.getData(), 0, acknowledgement.getLength());
   
   
   			  if(!(super.goodCheckSum(msgText))){
               System.out.println("CHECKSUM FAILED: "+msgText);
   				continue;
   			  }
              
              System.out.println("RECEIVED:\n"+ msgText+"\n------");
              
              
              if(name.equals("")){
      			  if(super.isAcknowledgement2(msgText)){//checks if it's an ack with a non-username sqnum
      				   Acks.add(msgText);
      				   numAcks++;//Once we have enough unique acks, the loop ends
                     gotAck=true;
      			  }
                 else{
                     if(super.stripCheckSum(msgText).equals(lastMessage)){
                     
                        String[] msgparts= super.stripCheckSum(msgText).split("\n");
                        sendAck(acknowledgement.getAddress(), acknowledgement.getPort(), msgparts[0], sourceSocket, msgText);
                        
                     }
                 }
              }
              else{
                 if(super.isAcknowledgement(msgText)){
      				   Acks.add(msgText);
      				   numAcks++;//Once we have enough unique acks, the loop ends
                     gotAck=true;
      			  }
                 else{
                     if(super.stripCheckSum(msgText).equals(lastMessage)){
                     
                        String[] msgparts= super.stripCheckSum(msgText).split("\n");
                        sendAck(acknowledgement.getAddress(), acknowledgement.getPort(), msgparts[0], sourceSocket, msgText);
                        
                     }
                 }

              }
           } 
              
              boolean StillWaiting;
              msgText= super.stripCheckSum(msgText);
               
              DatagramPacket memberList=
   			  new DatagramPacket(buf, buf.length);
              String[] msgparts= 
   			  msgText.split("\n");
              
              StillWaiting= true;
              while(StillWaiting){
   			  sourceSocket.setSoTimeout(0);//perpetual waiting
                    			  
			     sourceSocket.receive(memberList);               
			     msgText= new String(memberList.getData(), 0, memberList.getLength());

			     if(!(super.goodCheckSum(msgText))){//bad checksum
				   continue;
			     }
               
               if(super.isDuplicate(lastMessage,msgText)){
		         //checks if the whole packet was sent previously
                  System.out.println("DUPLICATE IN SEND FOR:\n"+msgText);
			         this.sendAck(memberList.getAddress(), memberList.getPort(), msgparts[0], socket0,msgText);
		         }
		         else{
			         lastMessage = msgText;
		         }
   
                
   			     if(isAvailableMembers(msgText)){
   				
   				   
   				   StillWaiting= false;//Once we have have the list of online members we stop the loop
                  
                  people="";
                  
                  
                  
                  msgparts= msgText.split("\n");
                  
                  
                 if(isRefresh){ 
                     for(int i = 3; i < (Integer.parseInt(msgparts[2])+3); i++){
                       if (!((this.name).equals(msgparts[i]))){  
                        people= people +msgparts[i]+ "\n";
                       }             
                     }
                 }
                 else{//if initial request
                     for(int i = 3; i < (Integer.parseInt(msgparts[2])+3); i++){
                        people= people +msgparts[i]+ "\n";        
                     }

                 }
                  
                 
                 this.sendAck(memberList.getAddress(), memberList.getPort(), msgparts[0].split(" ")[1], socket0, msgText);
   
                 } 
               } 
   		}
   		catch(SocketException e){
   			System.out.println("Socket exception when sending message");
   		}
         catch(IOException e){
              
              System.out.println("RESENDING DUE TO TIMEOUT");
              
              if(!gotAck){

               return sendFor(msg, destAddress, destPort,
	               sourceSocket, numReceivers, isRefresh);
              } 
   		}
         this.Sending=false;
         return people;
     }
	}

    /** Checks if the format of the message is that of an member list message
     *
     * @param msgText the message being checked
     * @return true if it was recognised as an memberlist message
     */
    private boolean isAvailableMembers(String msgText){

      String x= super.stripCheckSum(msgText);
      
      System.out.println("CHECKING IF THIS IS AN AVAILABLEMEMBERS MESSAGE:\n" + msgText);
      
      if(x.split("\n").length<2){
         System.out.println("NOT AN AVAILABLEMEMBERS MESSAGE");
         return false;
      }
      
		if(x.split("\n")[1].equals("Post: AvailableMembers")){
         System.out.println("IS AN AVAILABLEMEMBERS MESSAGE");
			return true;
		}
		else{
         System.out.println("NOT AN AVAILABLEMEMBERS MESSAGE");
			return false;
         
		}
	}

    /**
     * Run method
     */
    public void run(){
        while(!(this.HasQuit)){
            while(!HPButtonPressed && !(this.Sending)){
                
                                
                try{
                  socket0.setSoTimeout(100);//the purpose of the timeout is so that the program doesn't block on the receive method
                                          //because other functions will need to use the socket
                }                          
                catch(SocketException e){
                    System.out.println("SocketException when setting timer in homepage run method");
                }
                
                this.Receiving=true;
                receive();

                this.Receiving=false;
                
                try{
                  Thread.sleep(500);
                }
                catch(InterruptedException e){
                  System.out.println("Interrupted Exception when calling sleep in homepage's run method");
                }
                
                
            }
        }
        return;
    }

    /** Main method starts up the program
     *
     * @param args is an array of strings that should consist of only the host name of the user
     */
    public static void main(String[] args) {
        
       if (args.length != 1) {
            System.out.println("Correct syntax: HomePage <server hostname>");
            System.exit(0);
        }

        String hostnameS = args[0];
        int portS = 4446;

        try {
            InetAddress addressS = InetAddress.getByName(hostnameS);
            DatagramSocket socket0 = new DatagramSocket();
            
            HomePage h = new HomePage(socket0.getPort(), socket0.getInetAddress(), socket0, addressS, portS);

            h.setVisible(true);
            Thread t = new Thread(h);
            t.start();
        }

        catch (SocketException e) {
            System.out.println("Socket error.");
            System.exit(0);
        }

        catch(UnknownHostException e){
            System.out.println("Unknown Host.");
            System.exit(0);
        }

    }
}