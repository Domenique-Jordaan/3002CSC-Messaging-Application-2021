TO RUN:
	SERVER: java ChatHub <server hostname>
	CLIENT: java HomePage <server hostname>

The server-side classes are:
	User.java
	Server.java
	Server0.java
	ChatServer.java
	ChatHub.java

The client-side classes are:
	Client.java
	HomePage.java
	ChatWindow.java

NOTE FOR PACKET-LOSS CHECKING
If desired, set boolean flags "messUpMyPackets" in classes Client and Server to true to receive 40% packet corruption/dropping