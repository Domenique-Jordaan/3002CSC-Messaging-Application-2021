//Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
//April 2021
//Abstract parent Server class for Chat Application

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.Random;

/** Abstract parent Server class for Chat Application
 * @author Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
 * @version 1.0
 * @since 2021-04-03
 */
public abstract class Server{

	/**
	 * Group address
	 */
	public InetAddress gAddress;

	/**
	 * Group port
	 */
	public int gPort;

	/**
	 * Determines for avoiding resends
	 */
	public boolean isChatServer;
    //the above parameters are to help with impromptu resends when we get a resent message when expecting acks

	/**
	 * Sequence number starting from zero
	 */
	public int sequenceNumber;

	/**
	 * Boolean for Appendix A dropping
	 */
	private final boolean messUpMyPackets=false;

	/**
	 * Random number for messing up packets for Appendix A
	 */
	private Random r;

	/**
	 * Constructor
	 *
	 * @param isChatServer the boolean used for avoiding resends
	 */
	public Server(boolean isChatServer){
		sequenceNumber=0;
		Random r= new Random();
		this.isChatServer=isChatServer;
	}

	/** Calculates the check sum used for error-checking. Adds up all integer values of the letters in the message
	 *
	 * @param message the message being calculated
	 * @return the check sum value
	 */
	private int calculateCheckSum(String message){
		char[] msg= message.toCharArray();
		int sum=0;
		int j;
		for( char i: msg){
			j=i;
			sum+=j;
		}
		return sum;
	}

	/**
	 * Abstract receive method
	 */
	public abstract void receive();

	/** Sends the Datagram packet via a Datagaram socket
	 *
	 * @param message the message being sent by the server
	 * @param destAddress the destination address
	 * @param destPort the destination port number
	 * @param sourceSocket the source socket
	 * @param numReceivers the number of receivers of this packet
	 * @param lastMessage the last message sent
	 * @return true if it was sent successfully
	 */
	public synchronized boolean send
	(String message, InetAddress destAddress, int destPort,
	 DatagramSocket sourceSocket, int numReceivers, String lastMessage, User lastSender){ //changed to synchronized
  		System.out.println("WILL ACK FOR:\n" +lastMessage);
     

		message= sequenceNumber + "\n" + message;
		//adds sequenceNumber to Header
      
		message= calculateCheckSum(message) + " " + message ;
		//adds checkSum to Header

	    System.out.println("SENDING:\n"+message);

	    sequenceNumber++;
		
		DatagramPacket packet= new DatagramPacket
		(message.getBytes(), message.getBytes().length, destAddress, destPort);

		int numAcks=0; //The number of receipt acknowledgements
		//We need this to equal the number of receivers
      
      
        if(messUpMyPackets){
      	 r= new Random();
      	 DatagramPacket corruptPacket;
      	 switch(r.nextInt()%5){//40% of packets are messed up
      		case 0://corrupt it
      		   System.out.println("Corrupted Message Sent");
      		   String corrupt= "AssemblyDereferencingSymbol bill y'all "+ message + "Cache money baabehhh";
      		   corruptPacket= new DatagramPacket(corrupt.getBytes(), corrupt.getBytes().length, destAddress, destPort);
      		   try{
      			  sourceSocket.send(corruptPacket);//Sends the packet to the enclosed address(es)
      		   }
      		   catch (IOException e){
      			  System.out.println("IO Exception when sending");
      			  System.exit(0);
      		   }
      		   break;
      
      		case 1://don't send it
      		   System.out.println("Packet intentionally not sent");
      		   break;
      		default:
      		   try{
      			  sourceSocket.send(packet);//Sends the packet to the enclosed address(es)
      		   }
      		   catch (IOException e){
      			   System.out.println("IO Exception when sending");
      			   System.exit(0);
      		   }
      	 }
        }
        else{
      	  try{
      	  	sourceSocket.send(packet);//Sends the packet to the enclosed address(es)
      	  }
      	  catch (IOException e){
      		System.out.println("IO Exception when sending");
      		System.exit(0);
      	  }
        }
		
      int numLoops=0;
		ArrayList<String> Acks= new ArrayList<String>(numReceivers);
		//tracks all Acks "so far" in the loop below
		//We use this to check if a received Ack is a duplicate

		try{
			//The below waits for acknowledgement from all users 
			//the message was sent to
			//We already have from the people in Acks

			byte[] buf = new byte[512];

			DatagramPacket acknowledgement= new DatagramPacket(buf, buf.length);
            

			String msgText;//Used below to convert received messages to strings
         


			while(numAcks<numReceivers){
            System.out.println("Acks: " +numAcks + " Expecting: "+numReceivers);
            sourceSocket.setSoTimeout(500);
           
           numLoops++;

           if(numLoops==50){
           	System.out.println("A user was timed out in server");
           	return false;
           }

			  
			  sourceSocket.receive(acknowledgement);
				
			  msgText= new String(acknowledgement.getData(), 0, acknowledgement.getLength());
               
               
           System.out.println("RECEIVED WHEN EXPECTING ACK:\n"+ msgText+"\n------");//Trace: Server getting join when it expects ack

           System.out.println("LAST MESSAGE:\n"+lastMessage);

           if(stripChecksum(msgText).equals(lastMessage)){
              if(lastSender==null||stripChecksum(msgText).equals(lastSender.lastMessage)){                  
                  if(lastSender!=null){
                     System.out.println("IMPROMPTU ACK SENT FOR...\n"+lastMessage+"\nTO:"+lastSender.name
                                       +"\nWHILE AWAITING ACK FOR: \n" +message+"-----------------------------");
                  }
                  else{
                      System.out.println("IMPROMPTU ACK SENT FOR...\n"+lastMessage
                                       +"\nWHILE AWAITING ACK FOR: \n" +message+"-----------------------------");
                  }
                  String[] msgparts= stripChecksum(msgText).split("\n");
                  if(isChatServer){
                     sendAck(gAddress, gPort, msgparts[0], sourceSocket, msgText);
                  }
                  else{
                     sendAck(lastSender.address, lastSender.portID, msgparts[0], sourceSocket, msgText);
                  }
                  
               } 
           }

			  if(!(goodCheckSum(msgText))){//bad checksum
			      continue;
			  }

			  if(isAcknowledgement(msgText)&&!(Acks.contains(msgText))){
			  	//Checks if this is an ack and if it's not a duplicate
			  	//Adds the received message to Acks
				
      		   Acks.add(msgText);
               
      			numAcks++;//Once we have enough unique acks, the loop ends
			  }
           else{
               continue;
           }
			}
         
         System.out.println("RECEIVED ACKS:");
         
         for(String s:Acks){
            System.out.println(s);
         }
         System.out.println("___________________");
		}
		
      catch(SocketException e){ //changed to this
			System.out.println("Socket exception when sending message");
		}
      
      catch(IOException e){
			  	return resend(packet, sourceSocket, numReceivers-numAcks, Acks, numLoops, numAcks, message, lastMessage, lastSender);
		}

		return true;
	}



	/** Resends the Datagram packet if original send fails
	 *
	 * @param packet the DatagramPacket being sent
	 * @param sourceSocket the source socket
	 * @param numReceivers the number of receivers of this packet
	 * @param Acks the number of acknowledgements already received successfully in response to previous sends
	 * @param numLoops the number of times the message has been sent
	 * @param numAcks the number of acknowledgements expected to be received
	 * @param message the message being sent
	 * @param lastMessage the message sent previously
	 * @return true if it was sent successfully
	 */
	private synchronized boolean resend
		(DatagramPacket packet, DatagramSocket sourceSocket, int numReceivers, ArrayList<String> Acks, 
      int numLoops, int numAcks, String message, String lastMessage, User lastSender){

      System.out.println("RESENDING");
      
      if(messUpMyPackets){
         DatagramPacket corruptPacket;
         switch(r.nextInt()%5){//40% of packets are messed up
            case 0://corrupt it
               System.out.println("Corrupted Message Sent");
               String corrupt= "AssemblyDereferencingSymbol bill y'all "+ message + "Cache money baabehhh";
               corruptPacket= new DatagramPacket(corrupt.getBytes(), corrupt.getBytes().length, packet.getAddress(), packet.getPort());
               try{
   			      sourceSocket.send(corruptPacket);//Sends the packet to the enclosed address(es)
   		      }
   		      catch (IOException e){
   			      System.out.println("IO Exception when sending");
   			      System.exit(0);
   		      }
               break;
               
            case 1://don't send it
               System.out.println("Packet intentionally not sent");
               break;
            
            default:
               try{
   			      sourceSocket.send(packet);//Sends the packet to the enclosed address(es)
   		      }
         		catch (IOException e){
         			System.out.println("IO Exception when sending");
         			System.exit(0);
         		}

         }
      }
      
      else{
          try{
               sourceSocket.send(packet);//Sends the packet to the enclosed address(es)
           }
           
           catch (IOException e){//error catch
               System.out.println("IO Exception when sending");
               System.exit(0);
           }
      }
      
		try{

			byte[] buf = new byte[512];

			DatagramPacket acknowledgement = new DatagramPacket(buf, buf.length);

			String msgText;

			while(numAcks<numReceivers){
				sourceSocket.setSoTimeout(500);
           
           numLoops++;

			  if(numLoops==10){
            System.out.println("A user was timed out");
            System.out.println("EXPECTED ACK FOR:\n"+message+"\n-----");
				return false;
			  }

			  
			  sourceSocket.receive(acknowledgement);
				
			  msgText= new String
				   (acknowledgement.getData(), 0, acknowledgement.getLength());
               
               
           System.out.println("RECEIVED WHEN EXPECTING ACK:\n"+ msgText+"\n------");//Trace: Server getting join when it expects ack

           if(stripChecksum(msgText).equals(lastMessage)){
               if(lastSender==null||stripChecksum(msgText).equals(lastSender.lastMessage)){
               
                  if(lastSender!=null){
                     System.out.println("IMPROMPTU ACK SENT FOR...\n"+lastMessage+"\nTO:"+lastSender.name
                                       +"\nWHILE AWAITING ACK FOR: \n" +message+"-----------------------------");
                  }
                  else{
                      System.out.println("IMPROMPTU ACK SENT FOR...\n"+lastMessage
                                       +"\nWHILE AWAITING ACK FOR: \n" +message+"-----------------------------");
                  }
                  String[] msgparts= stripChecksum(msgText).split("\n");
                  if(isChatServer){
                     sendAck(gAddress, gPort, msgparts[0], sourceSocket, msgText);
                  }
                  else{
                     sendAck(lastSender.address, lastSender.portID, msgparts[0], sourceSocket, msgText);
                  }
                  
               } 
           }


			  if(!(goodCheckSum(msgText))){
				continue;
			  }

			  if(isAcknowledgement(msgText)&&
				!(Acks.contains(msgText))){
				
				Acks.add(msgText);
				numAcks++;
			  }
			}		

		}
		catch(SocketException e){
			System.out.println("Socket exception when sending message");
		}
      catch(IOException e){
			  	return resend(packet, sourceSocket, numReceivers-numAcks, Acks, numLoops, numAcks, message, lastMessage, lastSender);
		}

		return true;
	}

	/** Sends acknowledgements
	 *
	 * @param destAddr the destination address
	 * @param destPort the destination port
	 * @param sqNum the sequence number
	 * @param sourceSocket the source socket
	 * @param message the message that was received successfully
	 */
	public synchronized void sendAck
	(InetAddress destAddr, int destPort, String sqNum, DatagramSocket sourceSocket, String message){
      sqNum=sqNum.trim();
		String ack= sqNum+ " Post: Received";
      ack= calculateCheckSum(ack)+ " "+ ack;
      DatagramPacket ackGram;
      r=new Random();
      if(messUpMyPackets){
         switch(r.nextInt()%5){
            case 0:
               //corrupt it
               System.out.println("ACK INTENTIONALLY CORRUPTED");
               ack+= "I like big bytes and I cannot lie";
               ackGram= 
         		new DatagramPacket(ack.getBytes(), ack.getBytes().length, destAddr, destPort);
         		try{
         			sourceSocket.send(ackGram);
                  System.out.println("ACK SENT: \n"+ ack +"\nACKING FOR:\n"+message);
         		}
         		catch(IOException e){
         			System.out.println("IO Exception");
         			System.exit(0);
         		}
               break;

            case 1:
               System.out.println("ACK INTENTIONALLY DISCARDED");
               //don't send it
               break;
            default:
               //proceed as normal
               ackGram= 
         		new DatagramPacket(ack.getBytes(), ack.getBytes().length, destAddr, destPort);
         		try{
         			sourceSocket.send(ackGram);
                  System.out.println("ACK SENT: \n"+ ack +"\nACKING FOR:\n"+message);
         		}
         		catch(IOException e){
         			System.out.println("IO Exception");
         			System.exit(0);
         		}
         }
      }
      else{
   		ackGram= 
   		new DatagramPacket(ack.getBytes(), ack.getBytes().length, destAddr, destPort);
   		try{
   			sourceSocket.send(ackGram);
            System.out.println("ACK SENT: \n"+ ack +"\nACKING FOR:\n"+message);
   		}
   		catch(IOException e){
   			System.out.println("IO Exception");
   			System.exit(0);
   		}
      }
	}

	/** Returns true if check sum matches the message
	 *
	 * @param msgText the message being checked for errors
	 * @return true if check sum matches the message
	 */
	public boolean goodCheckSum(String msgText){
		String[] sep= separateChecksum(msgText);
      
      try{
        int foundCheckSum= Integer.parseInt(sep[0]);
      }
      catch(NumberFormatException e){
        return false;
      }

		if(calculateCheckSum(sep[1])!=Integer.parseInt(sep[0])){	
			return false;
		}

		return true;
	}

	/** Strips the check sum from the rest of the message
	 *
	 * @param msgText the message with the check sum included
	 * @return the message without the check sum
	 */
	public String stripChecksum(String msgText){
		return separateChecksum(msgText)[1];
	}

	/** Splits message into check sum and message
	 *
	 * @param msgText the message being split
	 * @return an array of Strings with the message separated from the check sum value
	 */
	private String[] separateChecksum(String msgText){
		String[] checksumAndMSG= msgText.split(" ",2);

		return checksumAndMSG;
	}

	/** Checks if the format of the message is that of an acknowledgement
	 *
	 * @param msgText the message being checked
	 * @return true if it was recognised as an acknowledgement
	 */
	private boolean isAcknowledgement(String msgText){
		String sq= Integer.toString(sequenceNumber-1);
      System.out.println("CHECKING IF RECEIVED MESSAGE IS AN ACK:");
		if(stripChecksum(msgText).split("\n")[0].equals(sq+ " Post: Received")){
         System.out.println(msgText+ "\n...WAS recognized as an ack");
			return true;
		}
		else{
         System.out.println(stripChecksum(msgText)+ "\n...WAS NOT recognized as an ack as it does not equal...\n"+ sq+ " Post: Received\n----------" );
			return false;
		}
	}
}