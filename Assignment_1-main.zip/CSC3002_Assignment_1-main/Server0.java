//Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
//April 2021
//Server0 class for Chat Application

import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.Random;

/** Server0 class for Chat Application
 * @author Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
 * @version 1.0
 * @since 2021-04-03
 */
public class Server0 extends Server{

	/**
	 * Socket used
	 */
	private DatagramSocket socket;

	/**
	 * List of online users
	 */
	private ArrayList<User> usersOnline;

	/**
	 * Generates port numbers for multicast sockets
	 */
	int portTracker;

	/**
	 * Generates port numbers for chatservers
	 */
	int serverPortTracker;

	/**
	 * Generates addresses - appends to 230.0.0.x
	 */
	int addrTracker;

	/**
	 * Port number
	 */
	int port;

	/** Constructor
	 *
	 * @param a the InetAddress used
	 * @param port the port number used
	 */
	public Server0(InetAddress a, int port){
		super(false);
		portTracker=5000;
      serverPortTracker=5100;
		addrTracker=0;
      usersOnline= new ArrayList<User>();
		try{
			this.socket= new DatagramSocket(port);
		}
		catch(SocketException e){
			System.out.println("Socket Exception");
			System.exit(0);
		}
	}

	/**
	 * Run method
	 */
	public void run(){
		while(true){
			receive();
		}
	}

	/**
	 * Receives packets
	 */
	public void receive(){

		byte[] buf = new byte[512];
		DatagramPacket msg= new DatagramPacket(buf, buf.length); 
      

		try{
         socket.setSoTimeout(0);
			socket.receive(msg);
		}

		catch (IOException e){
			System.out.println("IO Exception Server 0");
		}


		String msgText= new String(msg.getData(), 0, msg.getLength());
      	System.out.println("SERVER RECEIVED:\n" + msgText+"----------");

		if(!(super.goodCheckSum(msgText))){
         System.out.println("BadChecksum");
			return;
		}

		msgText= super.stripChecksum(msgText);
		String[] msgparts= 
			msgText.split("\n");
      
      if(msgparts.length==1){
         return;
      }
		
		if(isDuplicate(msg,msgText)){
         System.out.println("DUPLICATE DETECTED:\n"+msgText);
			super.sendAck(msg.getAddress(), msg.getPort(), msgparts[0], socket, msgText);
			return;
		}
		else{
         if(getUser(msg)!=null){
			   getUser(msg).setLastMessage(msgText);
         }
         
		}

		User u;			//Used as a placeholder to add users to the online list
		int listLen;		//Used to hold the lenths of various user lists
		String NewMessage;	//Used to store messages to be sent
		String chatName;	//Used to store chatnames for "create chat" cmds
		User[] ulist;		//Used to store lists of users for parsing into chats
		String time;		//Used to store time stamps for chat starts
      String grpAddress;
      int grpPort;
      int srvPort;
      
		switch(msgparts[1]){
      
		//I'm online Ping (Post: Join, Username)
		//REACTION: Add Username, address, port to active users list
			case "Post: Join":
				u= new User(msgparts[2], msg.getAddress(), msg.getPort());
            u.setLastMessage(msgText);
				usersOnline.add(u);
				super.sendAck
					(msg.getAddress(), msg.getPort(), msgparts[0], socket, msgText);
				break;

		//Who else is Online (Get: MembersList, INITIAL/REFRESH, (optionally)Username)
		//REACTION: Send an "AvailabilityList" message
			case "Get: MembersList":
            
            if(msgparts[2].equals("INITIAL")){
               listLen= usersOnline.size();
               NewMessage="Post: AvailableMembers\n";
				   NewMessage+= listLen+ "\n";
               for( User x: usersOnline ){
						NewMessage+= x.name +"\n";
				   }
            }
            else{
   				listLen= usersOnline.size()-1;
   				NewMessage="Post: AvailableMembers\n";
   				NewMessage+= listLen+ "\n";
   				for( User x: usersOnline ){
   				//adds all names except the caller's to the list
   					if(!(x.name.equals(msgparts[3]))){
   						NewMessage+= x.name +"\n";
   					}
   				}
            }
            
				super.sendAck
					(msg.getAddress(), msg.getPort(), msgparts[0], socket, msgText);
               
            super.send(NewMessage, msg.getAddress(), msg.getPort(), socket, 1, msgText, getUser(msg));
				break;

		//Please make a chat (Post: NewChat, ChatName, ListLength, Time, Username1,...N)
		//REACTION: Make a New ChatServer, tell it to connect those users
			case "Post: NewChat":
				chatName= msgparts[2];
				listLen= Integer.parseInt(msgparts[3]);
				ulist= new User[listLen];
				time= msgparts[4];

				for(int i=5; i<5+listLen; i++){
					try{
						ulist[i-5]= getUser(msgparts[i]);
					}

					catch (NullPointerException e){
						System.out.println("User " +msgparts[i] + " not found");
					}
				}

            grpAddress= "230.0.0."+addrTracker;//assigns port and address and increments tracker
            srvPort= serverPortTracker;
            grpPort= portTracker;
            addrTracker++;
            serverPortTracker++;
            portTracker++;
            
            //////////////////////////////////SENDING CONNECT-CHAT MESSAGE/////////////////
      		String connectMSG= "Post: ConnectChat\n";
      		connectMSG+= chatName + "\n";
            connectMSG+= ulist.length+"\n";
            
      		for (User us : ulist){
      			connectMSG+=us.name+"\n";
      		}
            
      		connectMSG+=time +"\n";
            connectMSG+= grpAddress+"\n";
            connectMSG+= grpPort+"\n";
            connectMSG+= srvPort+"\n";
      		
      		for(User use: ulist){
               System.out.println("SENDING TO: " + use.address + " " + use.portID);
      			super.send( connectMSG, use.address, use.portID, socket, 1, msgText, getUser(msg) );
      		}
            
				(new Thread(new ChatServer(chatName, ulist, time, grpPort, grpAddress, srvPort))).start();

				break;
		
      //I'm leaving (Get: End)
		//REACTION: Remove user from the active users list
			case "Get: End":
				kickUser(msg);
				super.sendAck
					(msg.getAddress(), msg.getPort(), msgparts[0], socket, msgText);
            System.out.println("Current Users: "+usersOnline);
            break;

			default:
				System.out.println("Server 0 did not understand "+ msgparts[1]);
		}
	}

	/** Removes user that sent the message
	 *
	 * @param msg the message sent by the user
	 */
	private void kickUser(DatagramPacket msg){
		User u=getUser(msg);
		usersOnline.remove(u);
	}

	/** Retrieves a user
	 *
	 * @param uname the name of the user being retrieved
	 * @return the user
	 */
	private User getUser(String uname){
		for( User u: usersOnline ){
			if (u.name.equals(uname)){
				return u;
			}
		}
		return null;
	}

	/** Retrieves a user - method used for duplicate checking
	 *
	 * @param msg the packet with the message sent by the user
	 * @return the user
	 */
	private User getUser(DatagramPacket msg){
		InetAddress a= msg.getAddress();
		int p= msg.getPort();
		for( User u: usersOnline ){
			if (p==u.portID){
				if (a.equals(u.address)){
					return u;
				}
			}
		}
		return null;
	}

	/** Checks if the received Datagram was already received earlier from the sender
	 *
	 * @param msg the packet sent
	 * @param msgText the last message received
	 * @return true if messages compared equal, hence a duplicate
	 */
	private boolean isDuplicate( DatagramPacket msg, String msgText ){
		InetAddress a= msg.getAddress();
		int p= msg.getPort();
		for( User u: usersOnline ){
			if (p==u.portID){
				if (a.equals(u.address)){
					return u.lastMessage.equals(msgText);
				}
			}
		}
      return false;
	}
}