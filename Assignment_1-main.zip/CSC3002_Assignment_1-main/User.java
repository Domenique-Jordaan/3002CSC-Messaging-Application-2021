//Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
//April 2021
//User class for Chat Application

import java.net.InetAddress;

/** User class for Chat Application
 * @author Claudia Greenberg, Domenique Jordaan, Elizabeth Stevenson
 * @version 1.0
 * @since 2021-04-12
 */
class User{

	/**
	* Username
	*/
	public String name;

	/**
	 * User's InetAddress
	 */
	public InetAddress address;

	/**
	 * Port ID of the chat that this user object is associated with
	 */
	public int portID;

	/**
	 * The last message sent by the user in the relevant chat
	 */
	public String lastMessage;

	/** Constructor
	 *
	 * @param n the username
	 * @param a the InetAddress
	 * @param id the port ID
	 */
	public User(String n, InetAddress a, int id){
		name=n;
		address=a;
		portID=id;
		lastMessage="";
	}

	/** Retrieves name
	 *
	 * @return the name
	 */
	public String name(){
		return this.name();
	}

	/** Retrieves InetAddress
	 *
	 * @return the address
	 */
	public InetAddress address(){
		return this.address();
	}

	/** Retrieves the port ID
	 *
	 * @return the port number/ID
	 */
	public int portID(){
		return this.portID();
	}

	/** Retrieves the last message sent by the user in the relevant chat
	 *
	 * @return the last message
	 */
	public String lastMessage(){
		return this.lastMessage();
	}

	/** Sets the last message
	 *
	 * @param s the last message sent by the user in the relevant chat
	 */
	public void setLastMessage(String s){
		this.lastMessage=s;
	}
}